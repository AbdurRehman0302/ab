A web application made using MVC architecture in nodejs and express. Users can register themselves and upload a 
campground with its images and details. The location of the campground can also be viewed on map using a service called 
mapbox. 
![5](https://github.com/Bilal-Ahmad123/YelpCamp/assets/80017963/5d33d617-fbde-4072-ae92-16309ae089ec)
![4](https://github.com/Bilal-Ahmad123/YelpCamp/assets/80017963/7ceedc0a-80f5-43e1-b887-0598cb92ac70)
![3](https://github.com/Bilal-Ahmad123/YelpCamp/assets/80017963/293a530b-151a-4c26-9d79-b15672244e18)
![2](https://github.com/Bilal-Ahmad123/YelpCamp/assets/80017963/4da698e2-3943-462a-9fd4-9c30023b8c36)
![1](https://github.com/Bilal-Ahmad123/YelpCamp/assets/80017963/e22c2fe1-6d68-42d0-9c51-106e129c98a0)
![6](https://github.com/Bilal-Ahmad123/YelpCamp/assets/80017963/accc9ee7-adeb-48f2-b1d4-e06c17c98fd3)
